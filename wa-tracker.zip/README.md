# WhatsApp Last Seen Tracker

Track when your WhatsApp contacts come online/offline. Built with Node.js + whatsapp-web.js + React, deployable on Render.

## Features
- Scan QR to connect your WhatsApp via WhatsApp Web
- Real-time online/offline tracking via Socket.io
- Session history and activity heatmap
- Online alerts / notification log
- Persistent sessions stored in SQLite (no external DB needed on Render free tier)

## Project Structure
```
wa-tracker/
├── backend/          # Node.js + Express + whatsapp-web.js
├── frontend/         # React + Vite
└── render.yaml       # Render deployment config
```

## Local Development

### Backend
```bash
cd backend
npm install
npm run dev
```
Open http://localhost:3001 — scan the QR code shown in terminal with WhatsApp.

### Frontend
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

## Deploying to Render

1. Push this repo to GitHub
2. Go to https://render.com → New → Blueprint
3. Connect your GitHub repo
4. Render reads `render.yaml` and creates both services automatically
5. After deploy, open the backend service URL → scan QR → connected!

> ⚠️ Use a secondary WhatsApp number. whatsapp-web.js violates WhatsApp ToS and may cause bans.
