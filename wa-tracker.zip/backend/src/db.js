const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

// On Render, use the persistent disk mount. Locally use ./sessions/
const SESSION_DIR = process.env.NODE_ENV === "production"
  ? "/app/sessions"
  : path.join(__dirname, "../sessions");

if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });

const DB_PATH = path.join(SESSION_DIR, "tracker.db");
const db = new Database(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT UNIQUE NOT NULL,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT NOT NULL,
    event TEXT NOT NULL,
    ts TEXT NOT NULL,
    FOREIGN KEY (phone) REFERENCES contacts(phone) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_sessions_phone ON sessions(phone);
  CREATE INDEX IF NOT EXISTS idx_sessions_ts ON sessions(ts);
`);

module.exports = { db, SESSION_DIR };
