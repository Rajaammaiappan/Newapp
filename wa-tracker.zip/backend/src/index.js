const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const qrcode = require("qrcode");
const path = require("path");
const { Client, LocalAuth } = require("whatsapp-web.js");
const { db, SESSION_DIR } = require("./db");

const app = express();
const server = http.createServer(app);

const FRONTEND_URL = process.env.FRONTEND_URL
  ? `https://${process.env.FRONTEND_URL}`
  : "http://localhost:5173";

const io = new Server(server, {
  cors: { origin: [FRONTEND_URL, "http://localhost:5173"], credentials: true },
});

app.use(cors({ origin: [FRONTEND_URL, "http://localhost:5173"], credentials: true }));
app.use(express.json());

// ─── WhatsApp State ───────────────────────────────────────────────────────────
let waState = {
  status: "disconnected", // disconnected | qr | connecting | ready
  qrDataUrl: null,
  info: null,
};

// ─── WhatsApp Client ──────────────────────────────────────────────────────────
const client = new Client({
  authStrategy: new LocalAuth({ dataPath: SESSION_DIR }),
  puppeteer: {
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-accelerated-2d-canvas",
      "--no-first-run",
      "--no-zygote",
      "--single-process",
      "--disable-gpu",
    ],
  },
});

client.on("qr", async (qr) => {
  console.log("QR received, generating data URL...");
  waState.status = "qr";
  waState.qrDataUrl = await qrcode.toDataURL(qr);
  io.emit("wa:state", waState);
});

client.on("loading_screen", (percent) => {
  waState.status = "connecting";
  io.emit("wa:state", { ...waState, percent });
});

client.on("authenticated", () => {
  console.log("WhatsApp authenticated!");
  waState.status = "connecting";
  waState.qrDataUrl = null;
  io.emit("wa:state", waState);
});

client.on("ready", async () => {
  console.log("WhatsApp client is ready!");
  const info = client.info;
  waState = { status: "ready", qrDataUrl: null, info: { name: info.pushname, phone: info.wid.user } };
  io.emit("wa:state", waState);

  // Re-subscribe all tracked contacts
  const contacts = db.prepare("SELECT phone FROM contacts").all();
  for (const c of contacts) {
    await subscribePresence(c.phone).catch(() => {});
  }
});

client.on("disconnected", (reason) => {
  console.log("WhatsApp disconnected:", reason);
  waState = { status: "disconnected", qrDataUrl: null, info: null };
  io.emit("wa:state", waState);
});

// ─── Presence Updates ─────────────────────────────────────────────────────────
client.on("presence_update", (presence) => {
  const phone = presence.id.user;
  const isOnline = presence.isOnline;
  const ts = new Date().toISOString();

  // Check contact is tracked
  const contact = db.prepare("SELECT * FROM contacts WHERE phone = ?").get(phone);
  if (!contact) return;

  // Save event
  db.prepare("INSERT INTO sessions (phone, event, ts) VALUES (?, ?, ?)").run(
    phone,
    isOnline ? "online" : "offline",
    ts
  );

  // Push to all browser clients
  io.emit("presence:update", { phone, isOnline, ts, contactName: contact.name });
  console.log(`${contact.name} (${phone}) is now ${isOnline ? "ONLINE" : "offline"}`);
});

// ─── Subscribe to contact presence ───────────────────────────────────────────
async function subscribePresence(phone) {
  const chatId = phone.replace(/\D/g, "") + "@c.us";
  const chat = await client.getChatById(chatId);
  await chat.subscribeToPresenceUpdates();
  console.log(`Subscribed to presence: ${phone}`);
}

// ─── Initialize WhatsApp ──────────────────────────────────────────────────────
console.log("Initializing WhatsApp client...");
client.initialize().catch((err) => {
  console.error("Failed to initialize WhatsApp client:", err.message);
});

// ─── Socket.io ────────────────────────────────────────────────────────────────
io.on("connection", (socket) => {
  console.log("Browser client connected:", socket.id);
  // Send current WA state immediately on connect
  socket.emit("wa:state", waState);

  socket.on("disconnect", () => {
    console.log("Browser client disconnected:", socket.id);
  });
});

// ─── REST API ─────────────────────────────────────────────────────────────────

// WA status
app.get("/api/status", (req, res) => res.json(waState));

// Get all contacts
app.get("/api/contacts", (req, res) => {
  const contacts = db.prepare("SELECT * FROM contacts ORDER BY name").all();
  res.json(contacts);
});

// Add a contact
app.post("/api/contacts", async (req, res) => {
  const { name, phone } = req.body;
  if (!name || !phone) return res.status(400).json({ error: "name and phone required" });

  const normalized = phone.replace(/\D/g, ""); // strip non-digits
  try {
    db.prepare("INSERT INTO contacts (name, phone) VALUES (?, ?)").run(name, normalized);
    if (waState.status === "ready") {
      await subscribePresence(normalized).catch((e) => console.warn("Subscribe failed:", e.message));
    }
    res.json(db.prepare("SELECT * FROM contacts WHERE phone = ?").get(normalized));
  } catch (e) {
    if (e.message.includes("UNIQUE")) return res.status(409).json({ error: "Contact already exists" });
    res.status(500).json({ error: e.message });
  }
});

// Delete a contact
app.delete("/api/contacts/:phone", (req, res) => {
  db.prepare("DELETE FROM contacts WHERE phone = ?").run(req.params.phone);
  res.json({ ok: true });
});

// Get sessions for a contact (last 7 days)
app.get("/api/contacts/:phone/sessions", (req, res) => {
  const rows = db
    .prepare(
      `SELECT * FROM sessions
       WHERE phone = ?
       AND ts > datetime('now', '-7 days')
       ORDER BY ts DESC
       LIMIT 200`
    )
    .all(req.params.phone);
  res.json(rows);
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
server.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
