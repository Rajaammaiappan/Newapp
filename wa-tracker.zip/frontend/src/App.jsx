import { useState, useEffect, useCallback } from "react";
import { socket, API } from "./socket.js";
import QRScreen from "./QRScreen.jsx";

// ─── Helpers ──────────────────────────────────────────────────────────────────
function timeAgo(ts) {
  const d = Date.now() - new Date(ts).getTime();
  if (d < 60000) return "just now";
  if (d < 3600000) return `${Math.floor(d / 60000)}m ago`;
  if (d < 86400000) return `${Math.floor(d / 3600000)}h ago`;
  return `${Math.floor(d / 86400000)}d ago`;
}
function fmt(ts) {
  return new Date(ts).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
}
function fmtDate(ts) {
  const d = new Date(ts), t = new Date(); t.setHours(0,0,0,0);
  const diff = t - new Date(ts).setHours(0,0,0,0);
  if (diff === 0) return "Today";
  if (diff === 86400000) return "Yesterday";
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

// Pair online/offline events into sessions
function pairSessions(events) {
  const sorted = [...events].sort((a, b) => new Date(a.ts) - new Date(b.ts));
  const sessions = [];
  let openStart = null;
  for (const e of sorted) {
    if (e.event === "online") openStart = new Date(e.ts);
    else if (e.event === "offline" && openStart) {
      sessions.push({ start: openStart, end: new Date(e.ts), duration: Math.round((new Date(e.ts) - openStart) / 60000) });
      openStart = null;
    }
  }
  if (openStart) sessions.push({ start: openStart, end: new Date(), duration: Math.round((Date.now() - openStart) / 60000), live: true });
  return sessions.reverse();
}

// Avatar colors
const COLORS = [
  ["#dcfce7","#166534"],["#dbeafe","#1e40af"],["#fce7f3","#9d174d"],
  ["#fff7ed","#9a3412"],["#f3e8ff","#6b21a8"],["#ecfdf5","#065f46"],
];
function avatarStyle(idx) {
  const [bg, color] = COLORS[idx % COLORS.length];
  return { bg, color };
}
function initials(name) {
  return name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);
}

// ─── Activity Bar (24 hour blocks) ───────────────────────────────────────────
function ActivityBar({ sessions, dayOffset }) {
  const base = new Date(); base.setHours(0,0,0,0);
  const dayStart = base.getTime() - dayOffset * 86400000;
  const dayEnd = dayStart + 86400000;
  const daySessions = sessions.filter(s => s.start.getTime() < dayEnd && s.end.getTime() > dayStart);
  return (
    <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
      {Array.from({ length: 24 }, (_, h) => {
        const hS = dayStart + h * 3600000, hE = hS + 3600000;
        const active = daySessions.some(s => s.start.getTime() < hE && s.end.getTime() > hS);
        return <div key={h} title={`${h}:00–${h+1}:00`} style={{ width: 7, height: active ? 18 : 7, borderRadius: 3, background: active ? "#25d366" : "#e5e7eb", flexShrink: 0 }} />;
      })}
    </div>
  );
}

// ─── Heatmap ──────────────────────────────────────────────────────────────────
function Heatmap({ sessions }) {
  const days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  const base = new Date(); base.setHours(0,0,0,0);
  const grid = days.map((_, d) =>
    Array.from({ length: 24 }, (_, h) => {
      const dayStart = base.getTime() - (6 - d) * 86400000;
      const hS = dayStart + h * 3600000, hE = hS + 3600000;
      return sessions.filter(s => s.start.getTime() < hE && s.end.getTime() > hS).length;
    })
  );
  const max = Math.max(...grid.flat(), 1);
  return (
    <div style={{ overflowX: "auto" }}>
      <div style={{ display: "grid", gridTemplateColumns: "32px repeat(24, 1fr)", gap: 2, minWidth: 540 }}>
        <div />{Array.from({length:24},(_,h)=>(
          <div key={h} style={{fontSize:9,color:"#bbb",textAlign:"center"}}>{h%6===0?`${h}h`:""}</div>
        ))}
        {days.map((day, d) => (
          [
            <div key={`l${d}`} style={{fontSize:10,color:"#999",display:"flex",alignItems:"center"}}>{day}</div>,
            ...Array.from({length:24},(_,h)=>{
              const v=grid[d][h];
              return <div key={h} style={{height:14,borderRadius:2,background:v>0?`rgba(37,211,102,${0.15+(v/max)*0.85})`:"#f3f4f6"}} title={`${day} ${h}:00 — ${v} event(s)`}/>;
            })
          ]
        ))}
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [waState, setWaState] = useState({ status: "disconnected" });
  const [contacts, setContacts] = useState([]);
  const [liveStatus, setLiveStatus] = useState({});    // phone -> {isOnline, lastSeen}
  const [selected, setSelected] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [loadingSessions, setLoadingSessions] = useState(false);
  const [tab, setTab] = useState("overview");
  const [notifications, setNotifications] = useState([]);
  const [unread, setUnread] = useState(0);
  const [filter, setFilter] = useState("all");
  const [showAdd, setShowAdd] = useState(false);
  const [addName, setAddName] = useState("");
  const [addPhone, setAddPhone] = useState("");
  const [addLoading, setAddLoading] = useState(false);
  const [addError, setAddError] = useState("");

  // ── Fetch contacts from backend ─────────────────────────────────────────────
  const loadContacts = useCallback(async () => {
    try {
      const res = await fetch(`${API}/api/contacts`);
      const data = await res.json();
      setContacts(data);
    } catch {}
  }, []);

  useEffect(() => { loadContacts(); }, [loadContacts]);

  // ── Socket events ──────────────────────────────────────────────────────────
  useEffect(() => {
    socket.on("wa:state", setWaState);
    socket.on("presence:update", ({ phone, isOnline, ts, contactName }) => {
      setLiveStatus(prev => ({ ...prev, [phone]: { isOnline, lastSeen: ts } }));
      if (isOnline) {
        setNotifications(prev => [{ id: Date.now(), phone, name: contactName, ts }, ...prev].slice(0, 50));
        setUnread(x => x + 1);
      }
      // Refresh sessions if this contact is selected
      setSelected(sel => {
        if (sel && sel.phone === phone) {
          loadSessionsFor(phone);
        }
        return sel;
      });
    });
    return () => { socket.off("wa:state"); socket.off("presence:update"); };
  }, []);

  // ── Load sessions for selected contact ─────────────────────────────────────
  async function loadSessionsFor(phone) {
    setLoadingSessions(true);
    try {
      const res = await fetch(`${API}/api/contacts/${phone}/sessions`);
      const data = await res.json();
      setSessions(pairSessions(data));
    } catch {}
    setLoadingSessions(false);
  }

  function selectContact(c) {
    setSelected(c);
    setTab("overview");
    loadSessionsFor(c.phone);
  }

  // ── Add contact ─────────────────────────────────────────────────────────────
  async function handleAdd() {
    setAddError("");
    if (!addName.trim() || !addPhone.trim()) return setAddError("Name and phone are required");
    setAddLoading(true);
    try {
      const res = await fetch(`${API}/api/contacts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: addName.trim(), phone: addPhone.trim() }),
      });
      const data = await res.json();
      if (!res.ok) return setAddError(data.error || "Failed to add");
      setContacts(prev => [...prev, data]);
      setAddName(""); setAddPhone(""); setShowAdd(false);
    } catch { setAddError("Network error"); }
    setAddLoading(false);
  }

  // ── Delete contact ──────────────────────────────────────────────────────────
  async function handleDelete(phone) {
    await fetch(`${API}/api/contacts/${phone}`, { method: "DELETE" });
    setContacts(prev => prev.filter(c => c.phone !== phone));
    if (selected?.phone === phone) { setSelected(null); setSessions([]); }
  }

  // ── Derived ─────────────────────────────────────────────────────────────────
  function contactStatus(c) {
    return liveStatus[c.phone] || { isOnline: false, lastSeen: null };
  }
  const onlineCount = contacts.filter(c => contactStatus(c).isOnline).length;
  const filtered = contacts.filter(c => {
    if (filter === "online") return contactStatus(c).isOnline;
    if (filter === "offline") return !contactStatus(c).isOnline;
    return true;
  });

  const totalMin = sessions.reduce((a, s) => a + s.duration, 0);
  const avgPerDay = sessions.length ? (totalMin / 7).toFixed(0) : 0;

  // ── Render ──────────────────────────────────────────────────────────────────
  if (waState.status !== "ready") return <QRScreen waState={waState} />;

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", background: "#f0f2f5" }}>

      {/* ── Header ── */}
      <header style={{ background: "#fff", borderBottom: "1px solid #e5e7eb", height: 56, display: "flex", alignItems: "center", padding: "0 20px", gap: 12, flexShrink: 0, position: "sticky", top: 0, zIndex: 20 }}>
        <div style={{ width: 32, height: 32, background: "#25d366", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M17.498 14.382c-.301-.15-1.767-.867-2.04-.966-.273-.101-.473-.15-.673.15-.197.295-.771.964-.944 1.162-.175.195-.349.21-.646.075-.3-.15-1.263-.465-2.403-1.485-.888-.795-1.484-1.77-1.66-2.07-.174-.3-.019-.465.13-.615.136-.135.301-.345.451-.523.146-.181.194-.301.297-.496.1-.21.049-.375-.025-.524-.075-.15-.672-1.62-.922-2.206-.24-.584-.487-.51-.672-.51-.172-.015-.372-.015-.571-.015-.2 0-.523.074-.797.359-.273.3-1.045 1.02-1.045 2.475s1.07 2.865 1.219 3.075c.149.195 2.105 3.195 5.1 4.485.714.3 1.27.48 1.704.629.714.227 1.365.195 1.88.121.574-.091 1.767-.721 2.016-1.426.255-.705.255-1.29.18-1.425-.074-.135-.27-.21-.57-.345z"/><path d="M20.52 3.449C18.24 1.245 15.24 0 12.045 0 5.463 0 .104 5.334.101 11.893c0 2.096.549 4.14 1.595 5.945L0 24l6.335-1.652c1.746.943 3.71 1.444 5.71 1.447h.006c6.585 0 11.946-5.336 11.949-11.896 0-3.176-1.24-6.165-3.48-8.45zm-8.475 18.304h-.005c-1.775 0-3.514-.477-5.031-1.38l-.361-.214-3.741.975.999-3.648-.235-.375c-.99-1.576-1.516-3.391-1.516-5.26.003-5.45 4.437-9.884 9.893-9.884 2.64 0 5.122 1.03 6.988 2.898 1.866 1.869 2.893 4.352 2.892 6.993-.003 5.45-4.438 9.884-9.884 9.884z"/></svg>
        </div>
        <span style={{ fontWeight: 700, fontSize: 17 }}>WA Tracker</span>
        <div style={{ fontSize: 13, color: "#888" }}>
          Connected as <strong style={{ color: "#111" }}>{waState.info?.name}</strong>
          <span style={{ marginLeft: 6, color: "#aaa" }}>+{waState.info?.phone}</span>
        </div>
        <div style={{ flex: 1 }} />
        <div style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 20, padding: "4px 12px", fontSize: 13, color: "#15803d", fontWeight: 500, display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ width: 7, height: 7, background: "#22c55e", borderRadius: "50%", animation: "pulse 2s infinite" }} />
          {onlineCount} online
        </div>
        <button onClick={() => { setTab("notifications"); setUnread(0); }} style={{ position: "relative", background: "none", border: "1px solid #e5e7eb", cursor: "pointer", padding: "6px 10px", borderRadius: 8, display: "flex", alignItems: "center", gap: 6, fontSize: 13, color: "#555" }}>
          🔔
          {unread > 0 && <span style={{ background: "#ef4444", color: "#fff", borderRadius: 99, fontSize: 10, fontWeight: 700, padding: "1px 5px" }}>{unread}</span>}
        </button>
      </header>

      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>

        {/* ── Sidebar ── */}
        <aside style={{ width: 280, background: "#fff", borderRight: "1px solid #e5e7eb", display: "flex", flexDirection: "column", flexShrink: 0 }}>
          <div style={{ padding: "12px 14px", borderBottom: "1px solid #f3f4f6" }}>
            {/* Filter pills */}
            <div style={{ display: "flex", gap: 4, marginBottom: 10 }}>
              {["all","online","offline"].map(f => (
                <button key={f} onClick={() => setFilter(f)} style={{
                  flex: 1, padding: "5px 4px", borderRadius: 8, border: "1px solid", cursor: "pointer",
                  borderColor: filter === f ? "#25d366" : "#e5e7eb",
                  background: filter === f ? "#f0fdf4" : "transparent",
                  color: filter === f ? "#15803d" : "#888",
                  fontSize: 12, fontWeight: 500, textTransform: "capitalize"
                }}>
                  {f}{f === "online" && onlineCount > 0 && <span style={{ marginLeft: 4, background: "#25d366", color: "#fff", borderRadius: 99, padding: "0 5px", fontSize: 10 }}>{onlineCount}</span>}
                </button>
              ))}
            </div>

            {/* Add button */}
            <button onClick={() => setShowAdd(v => !v)} style={{ width: "100%", padding: "8px 0", background: "#25d366", color: "#fff", border: "none", borderRadius: 10, fontSize: 13, fontWeight: 600, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
              <span style={{ fontSize: 18, lineHeight: 1 }}>+</span> Add contact
            </button>

            {showAdd && (
              <div style={{ marginTop: 10, padding: 12, background: "#f9fafb", borderRadius: 10, border: "1px solid #e5e7eb", animation: "fadeIn .2s ease" }}>
                <input value={addName} onChange={e => setAddName(e.target.value)} placeholder="Contact name" style={{ width: "100%", padding: "7px 10px", borderRadius: 7, border: "1px solid #ddd", fontSize: 13, marginBottom: 7 }} />
                <input value={addPhone} onChange={e => setAddPhone(e.target.value)} placeholder="Phone e.g. 919876543210" style={{ width: "100%", padding: "7px 10px", borderRadius: 7, border: "1px solid #ddd", fontSize: 13, marginBottom: 8 }} />
                {addError && <p style={{ fontSize: 12, color: "#ef4444", marginBottom: 6 }}>{addError}</p>}
                <button onClick={handleAdd} disabled={addLoading} style={{ width: "100%", padding: "7px 0", background: "#25d366", color: "#fff", border: "none", borderRadius: 7, fontSize: 13, fontWeight: 600, cursor: "pointer", opacity: addLoading ? 0.7 : 1 }}>
                  {addLoading ? "Adding…" : "Add"}
                </button>
                <p style={{ fontSize: 11, color: "#bbb", marginTop: 6, lineHeight: 1.5 }}>Enter full international number without +. E.g. 919876543210</p>
              </div>
            )}
          </div>

          {/* Contact list */}
          <div style={{ flex: 1, overflowY: "auto" }}>
            {filtered.length === 0 && (
              <p style={{ fontSize: 13, color: "#bbb", textAlign: "center", padding: "30px 16px" }}>
                {contacts.length === 0 ? "No contacts yet. Add one above." : "No contacts match this filter."}
              </p>
            )}
            {filtered.map((c, i) => {
              const { isOnline, lastSeen } = contactStatus(c);
              const av = avatarStyle(i);
              const isSel = selected?.phone === c.phone;
              return (
                <div key={c.phone} onClick={() => selectContact(c)} style={{
                  display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", cursor: "pointer",
                  background: isSel ? "#f0fdf4" : "transparent",
                  borderLeft: `3px solid ${isSel ? "#25d366" : "transparent"}`,
                  transition: "background .15s"
                }}>
                  <div style={{ position: "relative", flexShrink: 0 }}>
                    <div style={{ width: 40, height: 40, borderRadius: "50%", background: av.bg, color: av.color, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 14 }}>{initials(c.name)}</div>
                    <div style={{ position: "absolute", bottom: 1, right: 1, width: 11, height: 11, borderRadius: "50%", background: isOnline ? "#22c55e" : "#d1d5db", border: "2px solid #fff" }} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, fontSize: 13, color: "#111", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.name}</div>
                    <div style={{ fontSize: 11, color: isOnline ? "#16a34a" : "#9ca3af", marginTop: 1 }}>
                      {isOnline ? "● Online now" : lastSeen ? `Last seen ${timeAgo(lastSeen)}` : "Not seen yet"}
                    </div>
                  </div>
                  <button onClick={e => { e.stopPropagation(); handleDelete(c.phone); }} title="Remove" style={{ background: "none", border: "none", cursor: "pointer", color: "#ddd", fontSize: 16, padding: 2, lineHeight: 1 }}>×</button>
                </div>
              );
            })}
          </div>
        </aside>

        {/* ── Main ── */}
        <main style={{ flex: 1, overflowY: "auto", padding: 24, display: "flex", flexDirection: "column", gap: 18 }}>

          {/* Tabs */}
          <div style={{ display: "flex", gap: 4, background: "#fff", borderRadius: 12, padding: 4, border: "1px solid #e5e7eb", width: "fit-content" }}>
            {["overview","sessions","heatmap","notifications"].map(t => (
              <button key={t} onClick={() => { setTab(t); if (t === "notifications") setUnread(0); }} style={{
                padding: "6px 16px", borderRadius: 9, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 500,
                background: tab === t ? "#25d366" : "transparent", color: tab === t ? "#fff" : "#666", transition: "all .2s", textTransform: "capitalize"
              }}>
                {t}{t === "notifications" && unread > 0 && <span style={{ marginLeft: 5, background: "#ef4444", color: "#fff", borderRadius: 99, fontSize: 10, padding: "0 5px" }}>{unread}</span>}
              </button>
            ))}
          </div>

          {/* No contact selected */}
          {!selected && tab !== "notifications" && (
            <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 12, color: "#bbb" }}>
              <div style={{ fontSize: 48 }}>👈</div>
              <p style={{ fontSize: 15 }}>Select a contact from the sidebar</p>
            </div>
          )}

          {/* Overview */}
          {tab === "overview" && selected && (
            <>
              {/* Contact card */}
              <div style={{ background: "#fff", borderRadius: 16, padding: "20px 24px", border: "1px solid #e5e7eb", display: "flex", alignItems: "center", gap: 20, flexWrap: "wrap" }}>
                {(() => { const av = avatarStyle(contacts.findIndex(c=>c.phone===selected.phone)); const { isOnline, lastSeen } = contactStatus(selected); return (
                  <>
                    <div style={{ position: "relative" }}>
                      <div style={{ width: 64, height: 64, borderRadius: "50%", background: av.bg, color: av.color, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 22 }}>{initials(selected.name)}</div>
                      <div style={{ position: "absolute", bottom: 3, right: 3, width: 14, height: 14, borderRadius: "50%", background: isOnline ? "#22c55e" : "#d1d5db", border: "2.5px solid #fff" }} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 20 }}>{selected.name}</div>
                      <div style={{ fontSize: 13, color: "#888", marginTop: 2 }}>+{selected.phone}</div>
                      <span style={{ marginTop: 8, display: "inline-flex", alignItems: "center", gap: 5, padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: isOnline ? "#dcfce7" : "#f3f4f6", color: isOnline ? "#16a34a" : "#6b7280" }}>
                        <span style={{ width: 7, height: 7, borderRadius: "50%", background: isOnline ? "#22c55e" : "#9ca3af" }} />
                        {isOnline ? "Online right now" : lastSeen ? `Last seen ${timeAgo(lastSeen)}` : "Not seen yet"}
                      </span>
                    </div>
                  </>
                ); })()}
              </div>

              {/* Stats */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
                {[
                  { icon: "📊", label: "Total sessions", value: sessions.length },
                  { icon: "⏱", label: "Avg daily usage", value: `${avgPerDay} min` },
                  { icon: "🕐", label: "Total online time", value: `${totalMin} min` },
                ].map(s => (
                  <div key={s.label} style={{ background: "#fff", borderRadius: 12, padding: "16px 20px", border: "1px solid #e5e7eb" }}>
                    <div style={{ fontSize: 24, marginBottom: 6 }}>{s.icon}</div>
                    <div style={{ fontSize: 22, fontWeight: 700 }}>{loadingSessions ? "…" : s.value}</div>
                    <div style={{ fontSize: 12, color: "#888", marginTop: 2 }}>{s.label}</div>
                  </div>
                ))}
              </div>

              {/* 7-day bars */}
              <div style={{ background: "#fff", borderRadius: 16, padding: "20px 24px", border: "1px solid #e5e7eb" }}>
                <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Activity — last 7 days</div>
                {loadingSessions ? <p style={{ color: "#bbb", fontSize: 13 }}>Loading…</p> : (
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {[0,1,2,3,4,5,6].map(d => (
                      <div key={d} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                        <div style={{ width: 64, fontSize: 12, color: "#888", fontWeight: 500 }}>{fmtDate(Date.now() - d*86400000)}</div>
                        <ActivityBar sessions={sessions} dayOffset={d} />
                      </div>
                    ))}
                  </div>
                )}
                <p style={{ fontSize: 11, color: "#bbb", marginTop: 10 }}>Each bar = 1 hour. Green = online detected.</p>
              </div>
            </>
          )}

          {/* Sessions */}
          {tab === "sessions" && selected && (
            <div style={{ background: "#fff", borderRadius: 16, padding: "20px 24px", border: "1px solid #e5e7eb" }}>
              <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Sessions — {selected.name}</div>
              {loadingSessions ? <p style={{ color: "#bbb", fontSize: 13 }}>Loading…</p>
               : sessions.length === 0 ? <p style={{ color: "#bbb", fontSize: 13 }}>No sessions recorded yet. Tracking has just started — check back soon.</p>
               : sessions.map((s, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 14, padding: "11px 0", borderBottom: i < sessions.length-1 ? "1px solid #f3f4f6" : "none" }}>
                  <div style={{ width: 36, height: 36, borderRadius: "50%", background: s.live ? "#dcfce7" : "#f3f4f6", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 16 }}>
                    {s.live ? "🟢" : "⏱"}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 500, fontSize: 14 }}>{fmtDate(s.start)}</div>
                    <div style={{ fontSize: 12, color: "#888", marginTop: 1 }}>{fmt(s.start)} → {s.live ? "now" : fmt(s.end)}</div>
                  </div>
                  <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: s.duration > 5 ? "#dcfce7" : "#f3f4f6", color: s.duration > 5 ? "#16a34a" : "#6b7280" }}>
                    {s.duration} min{s.live ? " (live)" : ""}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* Heatmap */}
          {tab === "heatmap" && selected && (
            <div style={{ background: "#fff", borderRadius: 16, padding: "20px 24px", border: "1px solid #e5e7eb" }}>
              <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 4 }}>Weekly activity heatmap</div>
              <p style={{ fontSize: 13, color: "#888", marginBottom: 20 }}>Hours on X-axis · Days on Y-axis · Darker = more active</p>
              {loadingSessions ? <p style={{ color: "#bbb", fontSize: 13 }}>Loading…</p> : <Heatmap sessions={sessions} />}
              <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "#aaa" }}>
                Less {[0.1,0.3,0.5,0.7,0.9].map((o,i) => <div key={i} style={{ width: 14, height: 14, borderRadius: 3, background: `rgba(37,211,102,${o})` }} />)} More
              </div>
            </div>
          )}

          {/* Notifications */}
          {tab === "notifications" && (
            <div style={{ background: "#fff", borderRadius: 16, padding: "20px 24px", border: "1px solid #e5e7eb" }}>
              <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 16 }}>Online alerts</div>
              {notifications.length === 0
                ? <p style={{ color: "#bbb", fontSize: 13 }}>No notifications yet. Waiting for contacts to come online…</p>
                : notifications.map(n => (
                  <div key={n.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: "1px solid #f9fafb" }}>
                    <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#dcfce7", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 16 }}>🟢</div>
                    <div style={{ flex: 1 }}>
                      <span style={{ fontWeight: 600, fontSize: 14 }}>{n.name}</span>
                      <span style={{ fontSize: 14, color: "#555" }}> came online</span>
                      <div style={{ fontSize: 12, color: "#aaa", marginTop: 1 }}>{fmt(n.ts)} · {fmtDate(n.ts)}</div>
                    </div>
                  </div>
                ))
              }
            </div>
          )}

        </main>
      </div>
    </div>
  );
}
