export default function QRScreen({ waState }) {
  return (
    <div style={{
      minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
      background: "linear-gradient(135deg,#f0fdf4 0%,#dcfce7 100%)",
      flexDirection: "column", gap: 28, padding: 24,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ width: 44, height: 44, background: "#25d366", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <svg width="26" height="26" viewBox="0 0 24 24" fill="white">
            <path d="M17.498 14.382c-.301-.15-1.767-.867-2.04-.966-.273-.101-.473-.15-.673.15-.197.295-.771.964-.944 1.162-.175.195-.349.21-.646.075-.3-.15-1.263-.465-2.403-1.485-.888-.795-1.484-1.77-1.66-2.07-.174-.3-.019-.465.13-.615.136-.135.301-.345.451-.523.146-.181.194-.301.297-.496.1-.21.049-.375-.025-.524-.075-.15-.672-1.62-.922-2.206-.24-.584-.487-.51-.672-.51-.172-.015-.372-.015-.571-.015-.2 0-.523.074-.797.359-.273.3-1.045 1.02-1.045 2.475s1.07 2.865 1.219 3.075c.149.195 2.105 3.195 5.1 4.485.714.3 1.27.48 1.704.629.714.227 1.365.195 1.88.121.574-.091 1.767-.721 2.016-1.426.255-.705.255-1.29.18-1.425-.074-.135-.27-.21-.57-.345z"/>
            <path d="M20.52 3.449C18.24 1.245 15.24 0 12.045 0 5.463 0 .104 5.334.101 11.893c0 2.096.549 4.14 1.595 5.945L0 24l6.335-1.652c1.746.943 3.71 1.444 5.71 1.447h.006c6.585 0 11.946-5.336 11.949-11.896 0-3.176-1.24-6.165-3.48-8.45zm-8.475 18.304h-.005c-1.775 0-3.514-.477-5.031-1.38l-.361-.214-3.741.975.999-3.648-.235-.375c-.99-1.576-1.516-3.391-1.516-5.26.003-5.45 4.437-9.884 9.893-9.884 2.64 0 5.122 1.03 6.988 2.898 1.866 1.869 2.893 4.352 2.892 6.993-.003 5.45-4.438 9.884-9.884 9.884z"/>
          </svg>
        </div>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: "#111" }}>WA Tracker</h1>
          <p style={{ fontSize: 13, color: "#666" }}>Connect WhatsApp to get started</p>
        </div>
      </div>

      <div style={{
        background: "#fff", borderRadius: 20, padding: 32, textAlign: "center",
        border: "1px solid #e5e7eb", maxWidth: 380, width: "100%",
        animation: "fadeIn .4s ease",
      }}>
        {waState.status === "disconnected" && (
          <>
            <div style={{ fontSize: 48, marginBottom: 12 }}>📵</div>
            <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>Not connected</h2>
            <p style={{ fontSize: 14, color: "#888", lineHeight: 1.6 }}>
              Backend is starting up. QR code will appear here automatically.
            </p>
            <div style={{ marginTop: 20, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, color: "#aaa", fontSize: 13 }}>
              <div style={{ width: 16, height: 16, border: "2px solid #25d366", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 1s linear infinite" }} />
              Waiting for backend…
            </div>
          </>
        )}

        {waState.status === "qr" && (
          <>
            <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 6 }}>Scan QR Code</h2>
            <p style={{ fontSize: 13, color: "#888", marginBottom: 20, lineHeight: 1.6 }}>
              Open <strong>WhatsApp → Linked Devices → Link a Device</strong> and scan this QR code
            </p>
            {waState.qrDataUrl ? (
              <img src={waState.qrDataUrl} alt="WhatsApp QR Code"
                style={{ width: 220, height: 220, borderRadius: 12, border: "3px solid #25d366" }} />
            ) : (
              <div style={{ width: 220, height: 220, background: "#f3f4f6", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto" }}>
                <div style={{ width: 28, height: 28, border: "3px solid #25d366", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 1s linear infinite" }} />
              </div>
            )}
            <p style={{ marginTop: 16, fontSize: 12, color: "#bbb" }}>QR expires in ~20 seconds. Refresh page if expired.</p>
          </>
        )}

        {waState.status === "connecting" && (
          <>
            <div style={{ width: 52, height: 52, border: "4px solid #25d366", borderTopColor: "transparent", borderRadius: "50%", animation: "spin 1s linear infinite", margin: "0 auto 16px" }} />
            <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>Connecting…</h2>
            <p style={{ fontSize: 14, color: "#888" }}>WhatsApp Web is loading. This takes 10–30 seconds.</p>
          </>
        )}
      </div>

      <p style={{ fontSize: 12, color: "#aaa", maxWidth: 340, textAlign: "center", lineHeight: 1.7 }}>
        ⚠️ Use a secondary WhatsApp number. WhatsApp Web automation may violate ToS.
      </p>
    </div>
  );
}
