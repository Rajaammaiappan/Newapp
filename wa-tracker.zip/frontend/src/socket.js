import { io } from "socket.io-client";

const BACKEND =
  import.meta.env.VITE_BACKEND_URL
    ? `https://${import.meta.env.VITE_BACKEND_URL}`
    : "http://localhost:3001";

export const socket = io(BACKEND, { withCredentials: true, autoConnect: true });
export const API = BACKEND;
